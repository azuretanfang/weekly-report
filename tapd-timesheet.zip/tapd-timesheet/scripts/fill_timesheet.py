#!/usr/bin/env python3
"""
TAPD 工时自动填写脚本

从 ~/.codebuddy/mcp.json 读取个人令牌，调用 TAPD REST API 写入工时记录。

用法:
  # 写入单条工时
  python3 fill_timesheet.py \
    --entity-type story \
    --entity-id 1020398362087654321 \
    --owner "username" \
    --timespent 0.5 \
    --spentdate 2026-03-06 \
    --memo "IC营销活动需求开发"

  # 批量写入（从 JSON 文件）
  python3 fill_timesheet.py --batch timesheets.json

  # 查询某天已有工时
  python3 fill_timesheet.py --query --owner "username" --spentdate 2026-03-06

  # 查询日期范围内的工时
  python3 fill_timesheet.py --query --owner "username" --start-date 2026-03-02 --end-date 2026-03-06

  # 验证令牌是否可用
  python3 fill_timesheet.py --test-auth
"""

import argparse
import json
import os
import sys
from datetime import date, datetime
from typing import Optional

try:
    import requests
except ImportError:
    print("错误: 缺少 requests 库，请先安装: pip install requests", file=sys.stderr)
    sys.exit(1)


# === 常量 ===
WORKSPACE_ID = "20398362"
# 事务性独立 Task 统一使用的「任务」类别 ID（项目 20398362 的自定义工作项类型）
# 来自 tapd_field_detail_get 返回：workitem_type_id.options["1020398362000719993"] = "任务"
STANDALONE_TASK_WORKITEM_TYPE_ID = "1020398362000719993"
TAPD_API_BASE = "http://apiv2.tapd.woa.com"
MCP_CONFIG_PATH = os.path.expanduser("~/.codebuddy/mcp.json")
FALLBACK_CONFIG_PATH = os.path.expanduser("~/.tapd-timesheet.json")

VALID_ENTITY_TYPES = {"story", "task", "bug"}

# === 需求状态流转定义 ===
# 需求状态按流转顺序排列（索引越大表示越靠后）
STORY_STATUS_FLOW = [
    ("planning", "规划中"),
    ("status_5", "组内评审"),
    ("status_6", "待评审"),
    ("audited", "已评审"),
    ("status_19", "待排期"),
    ("status_4", "待开发"),
    ("status_25", "方案设计中"),
    ("developing", "开发中"),
    ("product_experience", "产品体验"),
    ("for_test", "转测试"),
    ("status_20", "测试中"),
    ("status_22", "灰度发布"),
    ("status_23", "灰度测试"),
    ("status_24", "全量发布"),
    ("status_10", "已完成"),
]

# 状态英文名 → 索引 的映射（用于比较先后）
STATUS_ORDER = {code: idx for idx, (code, _) in enumerate(STORY_STATUS_FLOW)}
# 为非主流程状态也分配合理的顺序值
STATUS_ORDER.update({
    "status_18": 0,    # 未开始 ≈ 规划中
    "status_16": 7,    # 实现中 ≈ 开发中
    "status_17": 14,   # 已实现 ≈ 已完成
    "status_21": 7,    # 进行中 ≈ 开发中
})
# 状态英文名 → 中文名 的映射
STATUS_CN = {code: cn for code, cn in STORY_STATUS_FLOW}
# 补充非主流程的状态中文名映射
STATUS_CN.update({
    "status_16": "实现中",
    "status_17": "已实现",
    "status_18": "未开始",
    "status_21": "进行中",
    "rejected": "已关闭",
    "status_15": "已拒绝",
    "status_9": "挂起",
})
# 中文名 → 英文名 的映射
STATUS_EN = {cn: code for code, cn in STATUS_CN.items()}

# 终态（不参与自动流转）
TERMINAL_STATUSES = {"rejected", "status_15", "status_9"}  # 已关闭、已拒绝、挂起

# 工时描述关键词 → 需求应该至少处于的状态
# 格式: (关键词列表, 最低状态英文名, 最低状态中文名)
KEYWORD_STATUS_RULES = [
    # 需求评审 → 至少「已评审」
    (["需求评审", "评审通过", "评审会", "需求评审会"], "audited", "已评审"),
    # 方案评审/设计 → 至少「方案设计中」
    (["方案评审", "方案设计", "技术方案", "方案讨论", "架构设计", "详细设计", "概要设计"], "status_25", "方案设计中"),
    # 开发/编码 → 至少「开发中」
    (["开发", "编码", "代码实现", "功能实现", "需求开发", "功能开发", "代码编写",
      "接口开发", "联调", "自测", "代码联调", "前端开发", "后端开发", "后台开发"], "developing", "开发中"),
    # 转测/测试支持 → 至少「转测试」
    (["转测", "测试支持", "提测", "转测试", "bug修复", "缺陷修复", "测试环境"], "for_test", "转测试"),
    # 灰度 → 至少「灰度发布」
    (["灰度", "灰度发布", "灰度验证", "灰度测试", "灰度上线"], "status_22", "灰度发布"),
    # 全量 → 至少「全量发布」或「已完成」
    (["全量", "全量发布", "全量上线", "正式发布", "正式上线"], "status_24", "全量发布"),
]


# === 凭证管理 ===

def load_credentials() -> dict:
    """
    加载 TAPD API 凭证。
    
    返回 dict:
      - {"type": "basic_auth", "user": str, "password": str}
      - {"type": "access_token", "token": str}
      - 若都无则返回 {"type": "none"}
    """
    # 优先级 1: Basic Auth（API 账号密码，最可靠）
    if os.path.exists(FALLBACK_CONFIG_PATH):
        try:
            with open(FALLBACK_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = json.load(f)
            user = config.get("tapd_api_user")
            password = config.get("tapd_api_password")
            if user and password:
                return {"type": "basic_auth", "user": user, "password": password}
            # 也检查是否有独立配置的 access_token
            token = config.get("tapd_access_token")
            if token:
                return {"type": "access_token", "token": token}
        except (json.JSONDecodeError, KeyError) as e:
            print(f"警告: 解析 {FALLBACK_CONFIG_PATH} 失败: {e}", file=sys.stderr)

    # 优先级 2: 从 MCP 配置读取个人令牌
    if os.path.exists(MCP_CONFIG_PATH):
        try:
            with open(MCP_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = json.load(f)
            token = (
                config.get("mcpServers", {})
                .get("tapd_mcp_http", {})
                .get("headers", {})
                .get("X-Tapd-Access-Token")
            )
            if token:
                return {"type": "access_token", "token": token}
        except (json.JSONDecodeError, KeyError) as e:
            print(f"警告: 解析 MCP 配置文件失败: {e}", file=sys.stderr)

    return {"type": "none"}


# === API 请求封装 ===

def make_request(method: str, endpoint: str, credentials: dict, **kwargs) -> dict:
    """
    发送 TAPD API 请求。
    
    根据 credentials 类型选择鉴权方式：
    - basic_auth: 使用 HTTP Basic Auth
    - access_token: 使用 X-Tapd-Access-Token Header，失败后尝试 Basic Auth 降级
    """
    url = f"{TAPD_API_BASE}/{endpoint}"
    headers = kwargs.pop("headers", {})

    if credentials["type"] == "basic_auth":
        auth = (credentials["user"], credentials["password"])
        try:
            response = requests.request(method, url, headers=headers, auth=auth, timeout=30, **kwargs)
        except requests.RequestException as e:
            return {"status": 0, "info": f"网络请求失败: {e}"}

        if response.status_code in (401, 403):
            return {
                "status": 0,
                "info": (
                    f"Basic Auth 鉴权失败(HTTP {response.status_code})。\n"
                    f"API 账号: {credentials['user']}\n"
                    "可能原因:\n"
                    "  1. API 账号或密码错误\n"
                    "  2. API 账号未被授权访问该项目(workspace_id)\n"
                    "  3. API 账号未被激活\n"
                    "请在 TAPD → 公司管理 → 安全与集成 → API账号管理 中检查"
                ),
            }

    elif credentials["type"] == "access_token":
        headers["X-Tapd-Access-Token"] = credentials["token"]
        try:
            response = requests.request(method, url, headers=headers, timeout=30, **kwargs)
        except requests.RequestException as e:
            return {"status": 0, "info": f"网络请求失败: {e}"}

        # 如果 token 鉴权失败，提示用户
        if response.status_code in (401, 403):
            return {
                "status": 0,
                "info": (
                    f"个人令牌鉴权失败(HTTP {response.status_code})。\n"
                    "MCP 个人令牌无法直接调用 TAPD REST API。\n"
                    f"请在 {FALLBACK_CONFIG_PATH} 中配置 API 账号密码:\n"
                    '{\n'
                    '  "tapd_api_user": "你的API账号",\n'
                    '  "tapd_api_password": "你的API密码"\n'
                    '}\n'
                    "申请方式: TAPD → 公司管理 → 安全与集成 → API账号管理"
                ),
            }
    else:
        return {
            "status": 0,
            "info": (
                "未找到任何 TAPD API 凭证。请配置以下任一方式:\n"
                f"  1. {FALLBACK_CONFIG_PATH} 中配置 tapd_api_user + tapd_api_password\n"
                f"  2. {MCP_CONFIG_PATH} 中配置 tapd_mcp_http (个人令牌)\n"
                f"  3. {FALLBACK_CONFIG_PATH} 中配置 tapd_access_token"
            ),
        }

    try:
        return response.json()
    except json.JSONDecodeError:
        return {"status": 0, "info": f"API 返回非 JSON 响应(HTTP {response.status_code}): {response.text[:200]}"}


# === 用户身份管理 ===

def load_saved_owner() -> Optional[str]:
    """
    从 ~/.tapd-timesheet.json 中读取已保存的 owner（企业微信英文名）。
    
    返回 owner 字符串，若未配置则返回 None。
    """
    if os.path.exists(FALLBACK_CONFIG_PATH):
        try:
            with open(FALLBACK_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = json.load(f)
            owner = config.get("owner")
            if owner and isinstance(owner, str) and owner.strip():
                return owner.strip()
        except (json.JSONDecodeError, KeyError):
            pass
    return None


def save_owner(owner: str) -> bool:
    """
    将 owner（企业微信英文名）保存到 ~/.tapd-timesheet.json。
    
    如果文件已存在，会保留原有字段，只更新 owner。
    如果文件不存在，会创建新文件。
    
    返回是否保存成功。
    """
    config = {}
    if os.path.exists(FALLBACK_CONFIG_PATH):
        try:
            with open(FALLBACK_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = json.load(f)
        except (json.JSONDecodeError, KeyError):
            config = {}
    
    config["owner"] = owner.strip()
    
    try:
        with open(FALLBACK_CONFIG_PATH, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        return True
    except IOError as e:
        print(f"错误: 无法写入配置文件 {FALLBACK_CONFIG_PATH}: {e}", file=sys.stderr)
        return False


# === 核心功能 ===

def short_id_to_long(short_id: str) -> str:
    """将 TAPD 短 ID 转换为长 ID"""
    short_id = str(short_id).strip()
    # 已经是长 ID（以 10 + workspace_id 开头）
    if short_id.startswith(f"10{WORKSPACE_ID}"):
        return short_id
    # 转换: "10" + workspace_id + short_id
    return f"10{WORKSPACE_ID}{short_id}"


def create_timesheet(
    credentials: dict,
    entity_type: str,
    entity_id: str,
    owner: str,
    timespent: str,
    spentdate: str,
    memo: str = "",
) -> dict:
    """创建一条工时记录"""
    if entity_type not in VALID_ENTITY_TYPES:
        return {
            "status": 0,
            "info": f"无效的 entity_type: {entity_type}，支持: {VALID_ENTITY_TYPES}",
        }

    # 确保使用长 ID
    long_id = short_id_to_long(entity_id)

    data = {
        "workspace_id": WORKSPACE_ID,
        "entity_type": entity_type,
        "entity_id": long_id,
        "owner": owner,
        "timespent": str(timespent),
        "spentdate": spentdate,
    }
    if memo:
        data["memo"] = memo

    return make_request("POST", "timesheets", credentials, data=data)


def query_timesheets(
    credentials: dict,
    owner: Optional[str] = None,
    spentdate: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    entity_type: Optional[str] = None,
    entity_id: Optional[str] = None,
    limit: int = 50,
    page: int = 1,
) -> dict:
    """查询工时记录，支持单日期或日期范围查询"""
    params = {"workspace_id": WORKSPACE_ID, "limit": limit, "page": page}
    if owner:
        params["owner"] = owner
    if spentdate:
        params["spentdate"] = spentdate
    if start_date:
        params["spentdate"] = f">={start_date}"
    if end_date:
        # 如果同时有 start_date，用逗号分隔组合范围
        if start_date:
            params["spentdate"] = f"{start_date}~{end_date}"
        else:
            params["spentdate"] = f"<={end_date}"
    if entity_type:
        params["entity_type"] = entity_type
    if entity_id:
        params["entity_id"] = short_id_to_long(entity_id)

    return make_request("GET", "timesheets", credentials, params=params)


def search_stories(
    credentials: dict,
    name: str,
    target_date: Optional[str] = None,
    owner_filter: Optional[str] = None,
    limit: int = 20,
) -> dict:
    """
    搜索需求（story），支持按名称模糊匹配 + 日期标题过滤 + 处理人/开发人员过滤。
    
    当 owner_filter 提供时，优先返回处理人（owner）或开发人员（developer）
    包含该用户名的需求。
    
    当 target_date 提供时（格式 YYYY-MM-DD），会在结果中筛选标题包含
    对应「X 月 X 日」或「X月X日」的需求，实现周期性工作的日期感知匹配。
    """
    params = {
        "workspace_id": WORKSPACE_ID,
        "name": name,
        "limit": limit,
        "fields": "id,name,status,created,owner,developer",
    }
    
    # 如果指定了 owner_filter，优先按 owner 过滤
    if owner_filter:
        params["owner"] = owner_filter
    
    result = make_request("GET", "stories", credentials, params=params)
    
    # 如果按 owner 过滤无结果，尝试按 developer 过滤
    if owner_filter and result.get("status") == 1:
        data = result.get("data", [])
        if not data:
            params_dev = dict(params)
            params_dev.pop("owner", None)
            params_dev["developer"] = owner_filter
            result = make_request("GET", "stories", credentials, params=params_dev)

    if result.get("status") != 1 or not target_date:
        return result

    # 按日期过滤：从 target_date 提取 M月D日 的多种格式
    try:
        dt = datetime.strptime(target_date, "%Y-%m-%d")
    except ValueError:
        return result

    month = dt.month
    day = dt.day
    # 生成多种日期格式用于匹配标题
    date_patterns = [
        f"{month} 月 {day} 日",   # 「3 月 2 日」（有空格）
        f"{month}月{day}日",       # 「3月2日」（无空格）
        f"{month}月 {day}日",      # 「3月 2日」
        f"{month} 月{day}日",      # 「3 月2日」
    ]

    data = result.get("data", [])
    filtered = []
    for item in data:
        story = item.get("Story", item)
        story_name = story.get("name", "")
        if any(pat in story_name for pat in date_patterns):
            filtered.append(item)

    return {
        "status": 1,
        "data": filtered,
        "info": f"按日期 {month}月{day}日 过滤后 {len(filtered)} 条（原始 {len(data)} 条）",
    }


def create_story(
    credentials: dict,
    name: str,
    description: str = "",
    owner: str = "",
) -> dict:
    """
    创建一个新需求（story）。
    
    用于为周期性工作（如研发周会）创建带日期标题的独立需求，
    方便多人复用写入工时。
    """
    data = {
        "workspace_id": WORKSPACE_ID,
        "name": name,
    }
    if description:
        data["description"] = description
    if owner:
        data["owner"] = owner

    return make_request("POST", "stories", credentials, data=data)


def create_task(
    credentials: dict,
    name: str,
    story_id: str = "",
    owner: str = "",
    description: str = "",
    iteration_id: str = "",
    status: str = "progressing",
    workitem_type_id: str = "",
) -> dict:
    """
    创建一个 task（任务）。
    
    支持两种模式：
      1. 关联主需求的子 Task：传入 story_id，task 会挂在该主需求下
      2. 独立 Task（不关联任何 Story）：story_id 留空，task 独立存在
         推荐同时传入 workitem_type_id="1020398362000719993"（项目 20398362 的「任务」类别）
    
    参数:
      - name: 任务标题
      - story_id: 关联的主需求 ID（长 ID 或短 ID 均可）。留空则创建独立 Task
      - owner: 任务处理人（TAPD 用户名）
      - description: 任务描述（可选）
      - iteration_id: 所属迭代 ID（可选）
      - status: 任务状态，默认 "progressing"（进行中）
                可选值: open(未开始) / progressing(进行中) / done(已完成)
      - workitem_type_id: 工作项类别 ID（可选）。独立 Task 建议传
                "1020398362000719993"（任务），这样在 TAPD 列表里显示为 TASK 类别
    
    返回: API 响应 dict
    """
    data = {
        "workspace_id": WORKSPACE_ID,
        "name": name,
        "status": status,
    }
    # story_id 有值时才关联主需求，否则创建独立 Task
    if story_id:
        data["story_id"] = short_id_to_long(story_id)
    if owner:
        data["owner"] = owner
    if description:
        data["description"] = description
    if iteration_id:
        data["iteration_id"] = iteration_id
    if workitem_type_id:
        data["workitem_type_id"] = workitem_type_id
    
    return make_request("POST", "tasks", credentials, data=data)


def infer_min_status_from_memo(memo: str) -> Optional[tuple]:
    """
    根据工时描述（memo）中的关键词，推断需求应该至少处于的最低状态。
    
    返回: (最低状态英文名, 最低状态中文名) 或 None（无匹配关键词）
    
    匹配规则按从后到前的顺序（全量 > 灰度 > 转测 > 开发 > 方案 > 评审），
    取匹配到的最高阶段，因为同一条工时描述中可能包含多个关键词。
    """
    if not memo:
        return None
    
    memo_lower = memo.strip()
    best_match = None
    best_order = -1
    
    for keywords, min_status, min_status_cn in KEYWORD_STATUS_RULES:
        for kw in keywords:
            if kw in memo_lower:
                order = STATUS_ORDER.get(min_status, -1)
                if order > best_order:
                    best_order = order
                    best_match = (min_status, min_status_cn)
                break  # 这组关键词已匹配，跳到下一组
    
    return best_match


def check_story_status(
    credentials: dict,
    entity_id: str,
) -> Optional[dict]:
    """
    查询单个需求的当前状态。
    
    返回 dict: {"id": ..., "name": ..., "status": ..., "status_cn": ..., "owner": ..., "developer": ...}
    或 None（查询失败）
    """
    long_id = short_id_to_long(entity_id)
    params = {
        "workspace_id": WORKSPACE_ID,
        "id": long_id,
        "fields": "id,name,status,owner,developer",
    }
    result = make_request("GET", "stories", credentials, params=params)
    
    if result.get("status") != 1:
        return None
    
    data = result.get("data", [])
    if not data:
        return None
    
    story = data[0].get("Story", data[0])
    current_status = story.get("status", "")
    return {
        "id": story.get("id"),
        "name": story.get("name"),
        "status": current_status,
        "status_cn": STATUS_CN.get(current_status, current_status),
        "owner": story.get("owner", ""),
        "developer": story.get("developer", ""),
    }


def should_update_status(current_status: str, min_status: str) -> bool:
    """
    判断是否需要更新需求状态。
    
    当且仅当：
    1. 当前状态不是终态（已关闭/已拒绝/挂起）
    2. 当前状态在状态流转链中排在 min_status 之前
    
    才需要将状态前推到 min_status。
    """
    # 终态不参与自动流转
    if current_status in TERMINAL_STATUSES:
        return False
    
    current_order = STATUS_ORDER.get(current_status, -1)
    min_order = STATUS_ORDER.get(min_status, -1)
    
    # 当前状态已经在 min_status 之后或等于，不需要更新
    if current_order >= min_order:
        return False
    
    return True


def update_story_status(
    credentials: dict,
    entity_id: str,
    new_status: str,
) -> dict:
    """
    更新需求状态。
    
    entity_id: 长 ID 或短 ID
    new_status: 目标状态英文名（如 "developing"）
    """
    long_id = short_id_to_long(entity_id)
    data = {
        "workspace_id": WORKSPACE_ID,
        "id": long_id,
        "status": new_status,
    }
    return make_request("POST", "stories", credentials, data=data)


def analyze_status_transition(
    credentials: dict,
    entity_type: str,
    entity_id: str,
    memo: str,
) -> Optional[dict]:
    """
    分析工时信息，判断对应需求是否需要状态流转。
    
    这是对外暴露的核心函数，综合调用上面的推断/查询/判断逻辑。
    
    返回 dict（需要流转时）:
    {
        "need_update": True,
        "story_id": "...",
        "story_name": "...",
        "current_status": "...",
        "current_status_cn": "...",
        "suggested_status": "...",
        "suggested_status_cn": "...",
        "matched_keyword": "...",
    }
    或 {"need_update": False, "reason": "..."} 
    或 None（非 story 类型，不参与分析）
    """
    # 只有 story 类型参与状态流转分析
    if entity_type != "story":
        return None
    
    # Step 1: 根据工时描述推断最低状态
    min_status_info = infer_min_status_from_memo(memo)
    if not min_status_info:
        return {"need_update": False, "reason": "工时描述中未匹配到状态流转关键词"}
    
    min_status, min_status_cn = min_status_info
    
    # Step 2: 查询需求当前状态
    story_info = check_story_status(credentials, entity_id)
    if not story_info:
        return {"need_update": False, "reason": f"无法查询到需求 {entity_id} 的状态"}
    
    # Step 3: 判断是否需要更新
    if should_update_status(story_info["status"], min_status):
        return {
            "need_update": True,
            "story_id": story_info["id"],
            "story_name": story_info["name"],
            "current_status": story_info["status"],
            "current_status_cn": story_info["status_cn"],
            "suggested_status": min_status,
            "suggested_status_cn": min_status_cn,
        }
    else:
        return {
            "need_update": False,
            "reason": (
                f"需求「{story_info['name']}」当前状态为「{story_info['status_cn']}」，"
                f"已在「{min_status_cn}」之后或相同，无需更新"
            ),
        }


def search_stories_in_iteration(
    credentials: dict,
    name: str,
    iteration_id: str,
    limit: int = 20,
) -> dict:
    """
    在指定迭代中搜索需求，按创建时间升序排列。
    
    优先在当前迭代中找匹配的需求，命中的话取创建时间最早的一条（主需求概率更大）。
    """
    params = {
        "workspace_id": WORKSPACE_ID,
        "name": name,
        "iteration_id": iteration_id,
        "limit": limit,
        "fields": "id,name,status,created,owner,developer,parent_id,iteration_id",
    }
    result = make_request("GET", "stories", credentials, params=params)
    
    if result.get("status") != 1:
        return result
    
    data = result.get("data", [])
    if not data:
        return result
    
    # 按创建时间升序排列（created 字段），取最早创建的（主需求概率大）
    sorted_data = sorted(data, key=lambda x: x.get("Story", x).get("created", ""))
    
    return {
        "status": 1,
        "data": sorted_data,
        "info": f"在迭代中找到 {len(sorted_data)} 条匹配需求（已按创建时间升序排列）",
    }


def delete_timesheet(
    credentials: dict,
    timesheet_id: str,
) -> dict:
    """
    删除一条工时记录（软删除，将 is_delete 设为 1）。
    
    通过 POST /timesheets 传入 id + is_delete=1 实现删除。
    """
    data = {
        "workspace_id": WORKSPACE_ID,
        "id": timesheet_id,
        "is_delete": "1",
    }
    return make_request("POST", "timesheets", credentials, data=data)


def batch_delete_timesheets(credentials: dict, timesheet_ids: list) -> list:
    """
    批量删除工时记录。
    
    timesheet_ids: list of str，每个元素是工时记录的 ID。
    返回: list of (timesheet_id, result_dict)
    """
    results = []
    for i, ts_id in enumerate(timesheet_ids):
        print(f"  [{i + 1}/{len(timesheet_ids)}] 删除工时 ID: {ts_id}", end=" ... ")
        result = delete_timesheet(credentials=credentials, timesheet_id=ts_id)
        if result.get("status") == 1:
            ts_data = result.get("data", {}).get("Timesheet", {})
            print(f"✅ 已删除 ({ts_data.get('spentdate', '?')} {ts_data.get('timespent', '?')}人天 {ts_data.get('memo', '')})")
        else:
            print(f"❌ 失败: {result.get('info', '未知错误')}")
        results.append((ts_id, result))
    return results


def batch_create_timesheets(credentials: dict, timesheets: list) -> list:
    """
    批量创建工时记录。
    
    timesheets: list of dict，每个 dict 包含:
      - entity_type: str
      - entity_id: str
      - owner: str
      - timespent: str/float
      - spentdate: str (YYYY-MM-DD)
      - memo: str (可选)
    
    返回: list of (timesheet_input, result_dict)
    """
    results = []
    for i, ts in enumerate(timesheets):
        print(f"  [{i + 1}/{len(timesheets)}] 写入: {ts.get('memo', ts.get('entity_type', ''))}", end=" ... ")
        result = create_timesheet(
            credentials=credentials,
            entity_type=ts["entity_type"],
            entity_id=str(ts["entity_id"]),
            owner=ts["owner"],
            timespent=str(ts["timespent"]),
            spentdate=ts["spentdate"],
            memo=ts.get("memo", ""),
        )
        status = "✅ 成功" if result.get("status") == 1 else f"❌ 失败: {result.get('info', '未知错误')}"
        print(status)
        results.append((ts, result))
    return results


def test_auth(credentials: dict) -> bool:
    """测试凭证是否可以正常调用 TAPD REST API"""
    print(f"测试 TAPD API 鉴权...")
    print(f"  鉴权方式: {credentials['type']}")
    if credentials["type"] == "access_token":
        print(f"  令牌前缀: {credentials['token'][:8]}...")
    elif credentials["type"] == "basic_auth":
        print(f"  API 用户: {credentials['user']}")
    print(f"  Workspace ID: {WORKSPACE_ID}")
    print(f"  API 地址: {TAPD_API_BASE}")
    print()

    result = query_timesheets(credentials, limit=1)
    if result.get("status") == 1:
        print("✅ 鉴权成功！可以正常调用 TAPD REST API。")
        data = result.get("data", [])
        if data:
            print(f"   返回了 {len(data)} 条工时记录示例。")
        return True
    else:
        print(f"❌ 鉴权失败: {result.get('info', '未知错误')}")
        print()
        print("解决方案:")
        print(f"  在 {FALLBACK_CONFIG_PATH} 中配置 API 账号密码:")
        print('  {')
        print('    "tapd_api_user": "你的API账号",')
        print('    "tapd_api_password": "你的API密码"')
        print('  }')
        print("  申请方式: TAPD → 公司管理 → 安全与集成 → API账号管理")
        return False


# === CLI 入口 ===

def main():
    parser = argparse.ArgumentParser(
        description="TAPD 工时自动填写工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 写入单条工时
  %(prog)s --entity-type story --entity-id 87654321 --owner "user" --timespent 0.5 --spentdate 2026-03-06

  # 批量写入
  %(prog)s --batch timesheets.json

  # 查询已有工时（单日）
  %(prog)s --query --owner "user" --spentdate 2026-03-06

  # 查询已有工时（日期范围，用于撤回所有）
  %(prog)s --query --owner "user" --start-date 2026-03-02 --end-date 2026-03-06

  # 搜索需求（优先匹配处理人为当前用户的需求）
  %(prog)s --search-story "研发周会" --date 2026-03-02 --owner-filter "user" --json

  # 创建需求（周期性工作）
  %(prog)s --create-story "【研发周会】3 月 2 日" --json

  # 删除工时（按工时 ID）
  %(prog)s --delete-timesheet 1120398362053931819

  # 批量删除工时（撤回所有，多个 ID 逗号分隔）
  %(prog)s --delete-timesheet 1120398362053931819,1120398362053931805

  # 测试鉴权
  %(prog)s --test-auth

  # 首次使用：保存企业微信英文名
  %(prog)s --set-owner "tanfang"

  # 查看已保存的用户名
  %(prog)s --get-owner

  # 在当前迭代中搜索需求（优先主需求）
  %(prog)s --search-iteration "空白对照" --json

  # 在指定迭代中搜索需求
  %(prog)s --search-iteration "空白对照" --iteration-id 1020398362002224029 --json

  # 在主需求下创建任务（当主需求不允许直接填写工时时）
  %(prog)s --create-task "空白对照方案设计" --entity-id 87654321 --owner "tanfang" --json

  # 检查需求状态是否需要流转（根据工时描述关键词）
  %(prog)s --check-status --entity-id 87654321 --memo "空白对照方案设计" --json

  # 更新需求状态
  %(prog)s --update-status developing --entity-id 87654321
        """,
    )

    # 模式选择
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--test-auth", action="store_true", help="测试凭证鉴权是否正常")
    mode.add_argument("--query", action="store_true", help="查询已有工时记录")
    mode.add_argument("--batch", type=str, metavar="FILE", help="从 JSON 文件批量写入工时")
    mode.add_argument("--search-story", type=str, metavar="NAME", help="按名称搜索需求（模糊匹配），配合 --date 可按日期过滤")
    mode.add_argument("--create-story", type=str, metavar="NAME", help="创建新需求（如周期性会议）")
    mode.add_argument("--delete-timesheet", type=str, metavar="IDS", help="删除工时记录，传入工时 ID（多个用逗号分隔）")
    mode.add_argument("--set-owner", type=str, metavar="NAME", help="保存企业微信英文名（TAPD 用户名）到配置文件")
    mode.add_argument("--get-owner", action="store_true", help="查看已保存的企业微信英文名")
    mode.add_argument("--check-status", action="store_true", help="分析工时描述，检查需求状态是否需要流转")
    mode.add_argument("--update-status", type=str, metavar="NEW_STATUS", help="更新需求状态（传入目标状态英文名）")
    mode.add_argument("--search-iteration", type=str, metavar="NAME", help="在当前迭代中搜索需求（按创建时间升序，优先主需求）")
    mode.add_argument("--create-task", type=str, metavar="NAME", help="在指定主需求下创建任务（task），需配合 --entity-id 指定主需求 ID")

    # 单条写入参数
    parser.add_argument("--entity-type", type=str, choices=["story", "task", "bug"], help="对象类型")
    parser.add_argument("--entity-id", type=str, help="对象 ID（短 ID 或长 ID 均可）")
    parser.add_argument("--owner", type=str, help="TAPD 用户名")
    parser.add_argument("--timespent", type=str, help="花费工时（人天）")
    parser.add_argument("--spentdate", type=str, default=date.today().isoformat(), help="日期 (YYYY-MM-DD)")
    parser.add_argument("--memo", type=str, default="", help="工时描述")

    # 搜索/创建需求参数
    parser.add_argument("--date", type=str, help="目标日期 (YYYY-MM-DD)，用于搜索需求时按日期标题过滤")
    parser.add_argument("--description", type=str, default="", help="需求描述（创建需求时可选）")
    parser.add_argument("--owner-filter", type=str, help="按处理人/开发人员过滤需求（优先匹配该用户负责的需求）")
    parser.add_argument("--iteration-id", type=str, help="迭代ID，用于在指定迭代内搜索需求")
    parser.add_argument("--standalone", action="store_true", help="创建独立 Task 模式：不传 story_id，自动设置 workitem_type_id 为「任务」类别（事务性工作专用）")
    parser.add_argument("--workitem-type-id", type=str, help="自定义工作项类别 ID（覆盖 --standalone 的默认值）")

    # 查询参数
    parser.add_argument("--limit", type=int, default=50, help="查询返回数量限制")
    parser.add_argument("--start-date", type=str, help="查询起始日期 (YYYY-MM-DD)，与 --end-date 配合做日期范围查询")
    parser.add_argument("--end-date", type=str, help="查询截止日期 (YYYY-MM-DD)，与 --start-date 配合做日期范围查询")

    # 输出控制
    parser.add_argument("--json", action="store_true", help="以 JSON 格式输出结果")

    args = parser.parse_args()

    # 加载凭证
    credentials = load_credentials()
    if credentials["type"] == "none":
        print(
            "错误: 未找到任何 TAPD API 凭证。\n"
            "请配置以下任一方式:\n"
            f"  1. {FALLBACK_CONFIG_PATH} 中配置 tapd_api_user + tapd_api_password（推荐）\n"
            f"  2. {MCP_CONFIG_PATH} 中配置 tapd_mcp_http (个人令牌)\n"
            f"  3. {FALLBACK_CONFIG_PATH} 中配置 tapd_access_token",
            file=sys.stderr,
        )
        sys.exit(1)

    # === 测试鉴权 ===
    if args.test_auth:
        success = test_auth(credentials)
        sys.exit(0 if success else 1)

    # === 设置用户名（保存企业微信英文名）===
    if args.set_owner:
        owner_name = args.set_owner.strip()
        if not owner_name:
            print("错误: 用户名不能为空", file=sys.stderr)
            sys.exit(1)
        if save_owner(owner_name):
            print(f"✅ 已保存企业微信英文名: {owner_name}")
            print(f"   配置文件: {FALLBACK_CONFIG_PATH}")
            print(f"   后续填写工时将自动使用此用户名。")
        else:
            print("❌ 保存失败", file=sys.stderr)
            sys.exit(1)
        return

    # === 查看已保存的用户名 ===
    if args.get_owner:
        saved_owner = load_saved_owner()
        if saved_owner:
            print(f"✅ 已保存的企业微信英文名: {saved_owner}")
        else:
            print("⚠️ 尚未配置企业微信英文名。")
            print(f"   请运行: python3 {sys.argv[0]} --set-owner \"你的企业微信英文名\"")
        return

    # === 自动加载已保存的 owner ===
    # 如果命令行未指定 --owner，则从配置文件读取
    if not args.owner:
        saved_owner = load_saved_owner()
        if saved_owner:
            args.owner = saved_owner

    # === 搜索需求（迭代内优先）模式 ===
    if args.search_iteration:
        iteration_id = args.iteration_id or "1020398362002224029"  # 默认：月迭代 26 年 3 月
        result = search_stories_in_iteration(
            credentials=credentials,
            name=args.search_iteration,
            iteration_id=iteration_id,
            limit=args.limit,
        )
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if result.get("status") == 1:
                data = result.get("data", [])
                if not data:
                    print(f"在迭代中未找到匹配「{args.search_iteration}」的需求。")
                    print(f"将扩大到全局搜索...")
                else:
                    print(f"在迭代中找到 {len(data)} 条匹配需求（按创建时间升序）:\n")
                    for i, item in enumerate(data):
                        story = item.get("Story", item)
                        parent_hint = f" (子需求, 父ID:{story.get('parent_id', '?')})" if story.get("parent_id") and story.get("parent_id") != "0" else " (主需求)"
                        print(
                            f"  #{i+1} [{STATUS_CN.get(story.get('status', ''), story.get('status', '?'))}] "
                            f"ID: {story.get('id')} "
                            f"「{story.get('name')}」{parent_hint} "
                            f"(创建: {story.get('created', '?')})"
                        )
                    print(f"\n💡 建议使用 #{1} (创建时间最早，主需求概率大)")
            else:
                print(f"搜索失败: {result.get('info', '未知错误')}", file=sys.stderr)
                sys.exit(1)
        return

    # === 检查需求状态是否需要流转 ===
    if args.check_status:
        if not args.entity_id:
            print("错误: --check-status 需要 --entity-id 参数", file=sys.stderr)
            sys.exit(1)
        if not args.memo:
            print("错误: --check-status 需要 --memo 参数（工时描述）", file=sys.stderr)
            sys.exit(1)
        
        entity_type = args.entity_type or "story"
        result = analyze_status_transition(
            credentials=credentials,
            entity_type=entity_type,
            entity_id=args.entity_id,
            memo=args.memo,
        )
        
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if result is None:
                print(f"ℹ️ 对象类型 {entity_type} 不参与需求状态流转分析")
            elif result.get("need_update"):
                print(f"⚠️ 建议更新需求状态：")
                print(f"   需求: 「{result['story_name']}」")
                print(f"   当前状态: {result['current_status_cn']} ({result['current_status']})")
                print(f"   建议状态: {result['suggested_status_cn']} ({result['suggested_status']})")
                print(f"\n   执行命令:")
                print(f"   python3 {sys.argv[0]} --update-status {result['suggested_status']} --entity-id {result['story_id']}")
            else:
                print(f"✅ 无需更新: {result.get('reason', '')}")
        return

    # === 更新需求状态 ===
    if args.update_status:
        if not args.entity_id:
            print("错误: --update-status 需要 --entity-id 参数", file=sys.stderr)
            sys.exit(1)
        
        new_status = args.update_status
        new_status_cn = STATUS_CN.get(new_status, new_status)
        
        # 先查询当前状态展示
        story_info = check_story_status(credentials, args.entity_id)
        if story_info:
            print(f"更新需求状态:")
            print(f"   需求: 「{story_info['name']}」 (ID: {story_info['id']})")
            print(f"   当前: {story_info['status_cn']} → 目标: {new_status_cn}")
        
        result = update_story_status(
            credentials=credentials,
            entity_id=args.entity_id,
            new_status=new_status,
        )
        
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if result.get("status") == 1:
                print(f"✅ 状态更新成功! → {new_status_cn}")
            else:
                print(f"❌ 更新失败: {result.get('info', '未知错误')}", file=sys.stderr)
                sys.exit(1)
        return

    # === 搜索需求模式 ===
    if args.search_story:
        # 优先使用 --owner-filter，其次用已保存的 owner
        owner_filter = getattr(args, 'owner_filter', None) or args.owner
        result = search_stories(
            credentials=credentials,
            name=args.search_story,
            target_date=args.date,
            owner_filter=owner_filter,
            limit=args.limit,
        )
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if result.get("status") == 1:
                data = result.get("data", [])
                if not data:
                    date_hint = f"（日期过滤: {args.date}）" if args.date else ""
                    print(f"未找到匹配「{args.search_story}」的需求{date_hint}。")
                    if args.date:
                        dt = datetime.strptime(args.date, "%Y-%m-%d")
                        suggested_name = f"【{args.search_story}】{dt.month} 月 {dt.day} 日"
                        print(f"\n建议创建新需求:")
                        print(f"  python3 {sys.argv[0]} --create-story \"{suggested_name}\" --json")
                else:
                    print(f"找到 {len(data)} 条匹配需求:\n")
                    for item in data:
                        story = item.get("Story", item)
                        print(
                            f"  [{story.get('status', '?')}] "
                            f"ID: {story.get('id')} "
                            f"「{story.get('name')}」 "
                            f"(创建: {story.get('created', '?')})"
                        )
            else:
                print(f"搜索失败: {result.get('info', '未知错误')}", file=sys.stderr)
                sys.exit(1)
        return

    # === 创建需求模式 ===
    if args.create_story:
        print(f"创建需求: 「{args.create_story}」")
        result = create_story(
            credentials=credentials,
            name=args.create_story,
            description=args.description,
            owner=args.owner or "",
        )
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if result.get("status") == 1:
                story_data = result.get("data", {}).get("Story", {})
                print(f"✅ 创建成功!")
                print(f"   ID: {story_data.get('id', 'N/A')}")
                print(f"   名称: {story_data.get('name', 'N/A')}")
                print(f"   链接: https://tapd.woa.com/tapd_fe/{WORKSPACE_ID}/story/detail/{story_data.get('id', '')}")
            else:
                print(f"❌ 创建失败: {result.get('info', '未知错误')}", file=sys.stderr)
                sys.exit(1)
        return

    # === 创建任务模式（支持独立 Task 和子 Task）===
    if args.create_task:
        # 判断创建模式：
        #   独立 Task：传 --standalone，此时不需要 --entity-id
        #   子 Task  ：不传 --standalone，必须传 --entity-id（主需求 ID）
        if args.standalone:
            if args.entity_id:
                print("提示: --standalone 模式下 --entity-id 会被忽略（独立 Task 不关联 Story）", file=sys.stderr)
            target_story_id = ""
            # 独立 Task 默认使用「任务」类别，除非用户显式覆盖
            target_workitem_type_id = args.workitem_type_id or STANDALONE_TASK_WORKITEM_TYPE_ID
            print(f"创建独立 Task: 「{args.create_task}」(workitem_type_id={target_workitem_type_id})")
        else:
            if not args.entity_id:
                print("错误: --create-task 需要 --entity-id 参数（指定关联的主需求 ID）\n"
                      "      或使用 --standalone 创建独立 Task（事务性工作）", file=sys.stderr)
                sys.exit(1)
            target_story_id = args.entity_id
            # 子 Task 默认不设置 workitem_type_id（除非用户显式指定）
            target_workitem_type_id = args.workitem_type_id or ""
            print(f"在需求 #{args.entity_id} 下创建任务: 「{args.create_task}」")

        result = create_task(
            credentials=credentials,
            name=args.create_task,
            story_id=target_story_id,
            owner=args.owner or "",
            description=args.description,
            iteration_id=args.iteration_id or "",
            status="progressing",  # 默认进行中
            workitem_type_id=target_workitem_type_id,
        )
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if result.get("status") == 1:
                task_data = result.get("data", {}).get("Task", {})
                task_id = task_data.get("id", "N/A")
                print(f"✅ 任务创建成功!")
                print(f"   ID: {task_id}")
                print(f"   名称: {task_data.get('name', 'N/A')}")
                print(f"   状态: 进行中 (progressing)")
                print(f"   关联需求: #{args.entity_id}")
                print(f"   链接: https://tapd.woa.com/tapd_fe/{WORKSPACE_ID}/task/detail/{task_id}")
            else:
                print(f"❌ 创建失败: {result.get('info', '未知错误')}", file=sys.stderr)
                sys.exit(1)
        return

    # === 删除工时模式 ===
    if args.delete_timesheet:
        ids = [tid.strip() for tid in args.delete_timesheet.split(",") if tid.strip()]
        if not ids:
            print("错误: 请提供至少一个工时 ID", file=sys.stderr)
            sys.exit(1)

        if len(ids) == 1:
            print(f"删除工时记录: ID={ids[0]}")
            result = delete_timesheet(credentials=credentials, timesheet_id=ids[0])
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                if result.get("status") == 1:
                    ts_data = result.get("data", {}).get("Timesheet", {})
                    print(f"✅ 删除成功!")
                    print(f"   ID: {ts_data.get('id', 'N/A')}")
                    print(f"   日期: {ts_data.get('spentdate', 'N/A')}")
                    print(f"   工时: {ts_data.get('timespent', 'N/A')}人天")
                    print(f"   对象: {ts_data.get('entity_type', '?')}#{ts_data.get('entity_id', '?')}")
                    print(f"   描述: {ts_data.get('memo', '(无)')}")
                else:
                    print(f"❌ 删除失败: {result.get('info', '未知错误')}", file=sys.stderr)
                    sys.exit(1)
        else:
            print(f"批量删除 {len(ids)} 条工时记录...\n")
            results = batch_delete_timesheets(credentials, ids)
            success_count = sum(1 for _, r in results if r.get("status") == 1)
            fail_count = len(results) - success_count
            print(f"\n完成: 成功删除 {success_count} 条, 失败 {fail_count} 条")

            if args.json:
                output = [{"id": tid, "result": r} for tid, r in results]
                print(json.dumps(output, ensure_ascii=False, indent=2))

            sys.exit(0 if fail_count == 0 else 1)
        return

    # === 查询模式 ===
    if args.query:
        result = query_timesheets(
            credentials=credentials,
            owner=args.owner,
            spentdate=args.spentdate if not (args.start_date or args.end_date) else None,
            start_date=args.start_date,
            end_date=args.end_date,
            entity_type=args.entity_type,
            entity_id=args.entity_id,
            limit=args.limit,
        )
        if args.json:
            print(json.dumps(result, ensure_ascii=False, indent=2))
        else:
            if result.get("status") == 1:
                data = result.get("data", [])
                if not data:
                    print("未找到工时记录。")
                else:
                    print(f"找到 {len(data)} 条工时记录:\n")
                    for item in data:
                        ts = item.get("Timesheet", item)
                        print(
                            f"  [{ts.get('spentdate')}] "
                            f"{ts.get('entity_type')}#{ts.get('entity_id')} "
                            f"→ {ts.get('timespent')}人天 "
                            f"by {ts.get('owner')} "
                            f"| {ts.get('memo', '')}"
                        )
            else:
                print(f"查询失败: {result.get('info', '未知错误')}", file=sys.stderr)
                sys.exit(1)
        return

    # === 批量写入模式 ===
    if args.batch:
        batch_file = args.batch
        if not os.path.exists(batch_file):
            print(f"错误: 批量文件不存在: {batch_file}", file=sys.stderr)
            sys.exit(1)
        with open(batch_file, "r", encoding="utf-8") as f:
            timesheets = json.load(f)
        if not isinstance(timesheets, list):
            print("错误: 批量文件内容必须是 JSON 数组", file=sys.stderr)
            sys.exit(1)

        print(f"准备写入 {len(timesheets)} 条工时记录...\n")
        results = batch_create_timesheets(credentials, timesheets)

        success_count = sum(1 for _, r in results if r.get("status") == 1)
        fail_count = len(results) - success_count
        print(f"\n完成: 成功 {success_count} 条, 失败 {fail_count} 条")

        if args.json:
            output = [{"input": ts, "result": r} for ts, r in results]
            print(json.dumps(output, ensure_ascii=False, indent=2))

        sys.exit(0 if fail_count == 0 else 1)

    # === 单条写入模式 ===
    required = ["entity_type", "entity_id", "owner", "timespent"]
    missing = [f"--{r.replace('_', '-')}" for r in required if not getattr(args, r)]
    if missing:
        print(f"错误: 单条写入模式缺少必要参数: {', '.join(missing)}", file=sys.stderr)
        parser.print_help()
        sys.exit(1)

    print(f"写入工时记录:")
    print(f"  对象: {args.entity_type}#{args.entity_id}")
    print(f"  用户: {args.owner}")
    print(f"  工时: {args.timespent}人天")
    print(f"  日期: {args.spentdate}")
    print(f"  描述: {args.memo or '(无)'}")
    print()

    result = create_timesheet(
        credentials=credentials,
        entity_type=args.entity_type,
        entity_id=args.entity_id,
        owner=args.owner,
        timespent=args.timespent,
        spentdate=args.spentdate,
        memo=args.memo,
    )

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        if result.get("status") == 1:
            ts_data = result.get("data", {}).get("Timesheet", {})
            print(f"✅ 写入成功! ID: {ts_data.get('id', 'N/A')}")
        else:
            print(f"❌ 写入失败: {result.get('info', '未知错误')}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
