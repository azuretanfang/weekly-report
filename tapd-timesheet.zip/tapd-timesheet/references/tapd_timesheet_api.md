# TAPD 工时花费 API 参考

## 新建工时花费

### 接口信息

- **URL**: `http://apiv2.tapd.woa.com/timesheets`
- **方法**: `POST`
- **格式**: JSON / Form URL Encoded

### 请求参数

| 字段名 | 必选 | 类型 | 说明 |
|--------|:----:|------|------|
| `workspace_id` | 是 | integer | 项目 ID。固定值 `20398362` |
| `entity_type` | 是 | string | 对象类型：`story`（需求）、`task`（任务）、`bug`（缺陷） |
| `entity_id` | 是 | integer | 对象 ID（**长 ID** 格式） |
| `timespent` | 是 | string | 花费工时（单位：人天，支持小数，如 0.1 表示 0.1 人天） |
| `owner` | 是 | string | 花费创建人（TAPD 用户名） |
| `spentdate` | 否 | date | 花费日期（格式：`YYYY-MM-DD`） |
| `timeremain` | 否 | string | 剩余工时 |
| `memo` | 否 | string | 花费描述 |

### 约束条件

- 同一 `entity_type` + `entity_id` + `spentdate` + `owner` 组合下，**只能有一条工时记录**
- `entity_id` 必须是**长 ID**（如 `1020398362087654321`），不是短 ID

### ID 转换规则

TAPD 对象有两种 ID 格式：

- **短 ID**：在 TAPD 页面 URL 中看到的 ID，如 `87654321`
- **长 ID**：API 调用需要使用的完整 ID

转换公式：`长 ID = "10" + workspace_id + 短 ID`

示例：
- workspace_id = `20398362`
- 短 ID = `87654321`
- 长 ID = `1020398362087654321`

也可通过 TAPD MCP 的 `tapd_id_get` 工具转换。

### 鉴权方式

#### 方式一：X-Tapd-Access-Token（推荐）

使用个人访问令牌，通过 HTTP Header 传递：

```
POST http://apiv2.tapd.woa.com/timesheets
Headers:
  X-Tapd-Access-Token: <your_access_token>
  Content-Type: application/x-www-form-urlencoded
Body:
  workspace_id=20398362&entity_type=story&entity_id=1020398362087654321&owner=username&timespent=4&spentdate=2026-03-06
```

个人令牌获取方式：TAPD → 右上角头像 → 个人设置 → 个人访问令牌 → 生成。

#### 方式二：Basic Auth（降级方案）

使用 API 账号密码进行 HTTP Basic 认证：

```bash
curl -u 'api_user:api_password' \
  -d 'workspace_id=20398362&entity_type=story&entity_id=1020398362087654321&owner=username&timespent=4&spentdate=2026-03-06' \
  'http://apiv2.tapd.woa.com/timesheets'
```

API 账号需要在 TAPD「公司管理 → API 账号管理」中申请。

### 请求示例（Python）

```python
import requests

url = "http://apiv2.tapd.woa.com/timesheets"
headers = {
    "X-Tapd-Access-Token": "your_token_here"
}
data = {
    "workspace_id": 20398362,
    "entity_type": "story",
    "entity_id": "1020398362087654321",
    "owner": "username",
    "timespent": "4",
    "spentdate": "2026-03-06",
    "memo": "需求开发"
}

response = requests.post(url, headers=headers, data=data)
print(response.json())
```

### 成功返回

```json
{
    "status": 1,
    "data": {
        "Timesheet": {
            "id": "1020398362001169003",
            "entity_type": "story",
            "entity_id": "1020398362087654321",
            "timespent": "4",
            "spentdate": "2026-03-06",
            "owner": "username",
            "created": "2026-03-06 18:08:35",
            "workspace_id": "20398362",
            "memo": "需求开发"
        }
    },
    "info": "success"
}
```

### 错误返回

```json
{
    "status": 0,
    "data": [],
    "info": "错误信息"
}
```

常见错误：
- `Timesheet already exists`: 同一对象同一天同一人已有工时记录
- `Unauthorized`: 鉴权失败，令牌无效或过期
- `entity_id is invalid`: 对象 ID 格式错误（可能用了短 ID）

## 查询工时花费

### 接口信息

- **URL**: `http://apiv2.tapd.woa.com/timesheets`
- **方法**: `GET`

### 请求参数

| 字段名 | 必选 | 类型 | 说明 |
|--------|:----:|------|------|
| `workspace_id` | 是 | integer | 项目 ID |
| `owner` | 否 | string | 花费创建人 |
| `spentdate` | 否 | date | 花费日期 |
| `entity_type` | 否 | string | 对象类型 |
| `entity_id` | 否 | integer | 对象 ID |
| `limit` | 否 | integer | 返回数量限制（默认 30，最大 200） |
| `page` | 否 | integer | 页码（从 1 开始） |

### 查询示例

查询某用户某天的所有工时记录：

```python
response = requests.get(
    "http://apiv2.tapd.woa.com/timesheets",
    headers={"X-Tapd-Access-Token": token},
    params={
        "workspace_id": 20398362,
        "owner": "username",
        "spentdate": "2026-03-06"
    }
)
```

## 删除工时花费

### 接口信息

- **URL**: `http://apiv2.tapd.woa.com/timesheets`
- **方法**: `POST`（通过设置 `is_delete=1` 实现软删除）
- **格式**: JSON / Form URL Encoded

**注意**：TAPD 不支持 `DELETE` 方法或 `/timesheets/delete` 端点。删除操作通过 POST 请求传入 `id` + `is_delete=1` 实现。

### 请求参数

| 字段名 | 必选 | 类型 | 说明 |
|--------|:----:|------|------|
| `workspace_id` | 是 | integer | 项目 ID。固定值 `20398362` |
| `id` | 是 | string | 工时记录 ID（从查询接口获取） |
| `is_delete` | 是 | string | 固定传 `"1"` 表示删除 |

### 请求示例

```bash
curl -u 'api_user:api_password' \
  -d 'workspace_id=20398362&id=1120398362053931819&is_delete=1' \
  'http://apiv2.tapd.woa.com/timesheets'
```

### 成功返回

```json
{
    "status": 1,
    "data": {
        "Timesheet": {
            "id": "1120398362053931819",
            "entity_type": "story",
            "entity_id": "1020398362130740942",
            "timespent": "0.5",
            "spentdate": "2026-03-06",
            "owner": "username",
            "is_delete": "1"
        }
    },
    "info": "success"
}
```

### 使用流程

1. 先通过 **查询接口**（GET）找到要删除的工时记录，获取其 `id`
2. 再通过 **POST 请求** 传入 `id` + `is_delete=1` 执行删除
3. 删除为软删除，`is_delete` 字段从 `"0"` 变为 `"1"`
